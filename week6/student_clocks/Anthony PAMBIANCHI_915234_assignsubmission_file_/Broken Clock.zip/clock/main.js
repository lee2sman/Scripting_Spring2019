var h = new Date();
document.getElementById("Hour").innerHTML = h.getHours();
var m = new Date();
document.getElementById("Min").innerHTML = m.getMinutes();
var s = new Date();
document.getElementById("Sec").innerHTML = s.getSeconds();



// I'm honestly not sure how to link the Script properly, So I did it in the HTML
