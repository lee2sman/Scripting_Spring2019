//notice how things are nested inside other things

// in plain text:

//Once the program loads
//   if you click #invest
//      fade in #hiddenText
//      and hide #invest button

//   if you click #solutionize
//      change the background image to images/disaster.jpg

//and here it is in code
$(document).ready(function() { //once the program loads
  $('#invest').click(function() { //if you click on invest button
    $('#hiddenText2').hide();
    $('#hiddenText4').hide();
    $('#hiddenText').fadeIn(); //then fade in the element with the id #hiddenText
    $('#invest').hide(); //and hide the button with the id name #invest
  });



  $('#joinNow').click(function(){ //if you click #solutionize
    $('body').css('background-image','url(images/aliens.jpg)');
      $('#hiddenText2').fadeIn();
      //change background image of page
  })
  $('#apply').click(function(){ //if you click #solutionize
    $('body').css('background-image','url(images/aliens.jpg)');
      $('#hiddenText4').fadeIn();
      //change background image of page
  })

});
