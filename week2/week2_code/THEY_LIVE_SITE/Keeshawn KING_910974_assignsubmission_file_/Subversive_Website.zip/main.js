$(document).ready(function(){
  $function myFunction(){
  $('#f').click(function(){
      $('#truth').fadeIn();
      $('#f').hide();
    });
  };
});
