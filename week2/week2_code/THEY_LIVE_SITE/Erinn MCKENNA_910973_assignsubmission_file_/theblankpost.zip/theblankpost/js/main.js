
$(document).ready(function(){
  $("button").click(function(){
    location.assign("index_lizard.html")
    // $("#p1").replaceWith("Meat Puppet Delivers Speech, Continues to Fool Puny Humans for 747th Day");
    // $("#p2").replaceWith("the text u know?");
    // $("#p3").replaceWith("the text u know?");
    // $("#p4").replaceWith("the text u know?");
    // $("#p5").replaceWith("the text u know?");
    // $("#p6").replaceWith("the text u know?");
    // $("#p7").replaceWith("the text u know?");
  });
});

var d = new Date();
var months = ["January","February","March","April","May","June","July","August","September","October","November","December"];
document.getElementById("todays_date").innerHTML = months[d.getMonth()] + ' ' + d.getDate() + ',' + ' ' + d.getFullYear();
