

$(document).ready(function(){

  $("#link").click(function(){
    $("#main").hide();
		$("#main2").hide();
    $("header").hide();

    $("p").append(" buy more Appel products.");
});

$("#link").click(function(){
  alert("Your old model product will be purposefully slowed down by our company once the most recent product is released! But Appel tech support is here to help, as long as you pay the required fees!");
});

});
